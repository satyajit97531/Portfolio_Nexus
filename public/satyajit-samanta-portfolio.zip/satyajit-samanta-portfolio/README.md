# Satyajit Samanta - Portfolio Nexus

Full-Stack Developer | MERN & Local AI Systems | iOS Developer
B.Tech Computer Science & Engineering · Roll No: 23DGITM425
Delhi Global Institute of Technology (DGIT) / MERI · Maharshi Dayanand University (MDU)

## 🚀 Quick Start Guide

### Prerequisites
- Node.js (v18 or higher recommended)
- npm or yarn

### Installation
1. Open terminal inside this folder:
   ```bash
   cd satyajit-samanta-portfolio
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Start development server:
   ```bash
   npm run dev
   ```

4. Open `http://localhost:3000` in your browser.

## 🛠️ Tech Stack & Features
- **Frontend**: React 19, TypeScript, Tailwind CSS, Motion
- **3D Interactive Graphics**: Three.js Orbital Canvas with soft blurred celestial rings
- **Local AI Integration**: Ollama LLM integration architecture (Llama/Mistral)
- **Mobile Development**: Native iOS Architecture & Swift
- **Design System**: Atomic UI components engineered in Figma
- **Competitive Profiles**: LeetCode (@satyajitzzzzz) & Codeforces (@satyajitzzz)
- **Resume Included**:
  - `public/Satyajit_Samanta_Resume.pdf` (Printable & Applicant-Ready PDF)
  - `public/Satyajit_Samanta_Resume.html` (Standalone HTML format)

## 👤 Contact Satyajit Samanta
- Email: satyajit97531@gmail.com
- Phone: +91 8076522382
- GitHub: https://github.com/satyajit97531
- LinkedIn: https://www.linkedin.com/in/satyajit-samanta-07a461385/
- LeetCode: https://leetcode.com/u/satyajitzzzzz/
- Codeforces: https://codeforces.com/profile/satyajitzzz
