# Satyajit Samanta - Portfolio Nexus

Full-Stack Developer | MERN & Local AI Systems | iOS Developer
B.Tech Computer Science & Engineering · Roll No: 23DGITM425
Delhi Global Institute of Technology (DGIT) · Maharshi Dayanand University (MDU)

## 🚀 Quick Start Guide

### Prerequisites
- Node.js (v18+ recommended)
- npm or yarn

### Installation & Launch
1. Open terminal inside this folder:
   ```bash
   cd satyajit-samanta-portfolio
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Start development server (Full-stack Express + Vite):
   ```bash
   npm run dev
   ```

4. Open `http://localhost:3000` in your browser.

5. (Optional) Production build:
   ```bash
   npm run build
   npm start
   ```

## 🛠️ Tech Stack & Highlights
- **Full-Stack Core**: Express.js + Vite + TypeScript backend with MongoDB Atlas integration
- **Sound & Audio FX**: Web Audio API Sound Engine featuring:
  - Toggle sound effect with smooth reverberant spatial echo
  - Calming, smooth ambient space synthesizer background music
  - Sound controls toolbar (Mute, Volume, SFX, Ambient toggles)
- **Frontend & Animations**: React 19, TypeScript, Tailwind CSS, Motion
- **3D Celestial Graphics**: Three.js Orbital Canvas with celestial particle field and rings
- **Local AI & MERN**: Architecture conditioned for Ollama (Llama/Mistral) local models
- **Mobile Engineering**: Native iOS Architecture & Swift
- **Design System**: Atomic UI components engineered in Figma (Games 24 storefront)
- **Competitive Programming**: LeetCode (@satyajitzzzzz, 50+ Solved)
- **Resume Assets**:
  - `public/Satyajit_Samanta_Resume.pdf` (Latest single-page applicant-ready PDF)
  - `public/Satyajit_Samanta_Resume.html` (Standalone responsive HTML resume)

## 👤 Contact Satyajit Samanta
- Email: satyajit97531@gmail.com
- Phone: +91 8076522382
- Location: Janakpuri, New Delhi, India
- GitHub: https://github.com/satyajit97531
- LinkedIn: https://www.linkedin.com/in/satyajit-samanta-07a461385/
- LeetCode: https://leetcode.com/u/satyajitzzzzz/
